<?php include '../view/header.php'; ?>
<main>
<nav>
    <h1>Error</h1>
    <p><?php echo $error; ?></p>
     </nav>
</main>
<?php include '../view/footer.php'; ?>