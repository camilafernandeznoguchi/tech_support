# tech_support
CS350-Project

## Colaborators
- Camila Fernandez
- Gabriela Hernandez
- Juliana Spitzner

## To Change DB connection
model -> database.php

## Git commands

- git checkout dev (move to branch dev)

...code...

- git add .
- git commit -m"Enter message here"
- git push origin dev

...when ready to merge...

- git checkout main (move to branch main)
- git merge dev (marges dev to main)
