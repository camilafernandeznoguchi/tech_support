<!--Produced by: Gabriela Hernandez-->

<?php 
session_start();

require('../view/header.php');

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


try {
	# Connecting to database
	require('../model/database.php');

	# Checking connection
	if (mysqli_connect_error($con)) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error() . "<br>";
		exit("Connect Error");
	}
	
	$productname = $_POST["registerProduct"];
	
	$query = "SELECT productCode FROM products WHERE name = '$productname';";
	
    $result = mysqli_query($con, $query) or die('Query failed: ' . mysqli_errno($con));
    $line = mysqli_fetch_array($result, MYSQLI_ASSOC);
    
	
}
catch (Exception $e) {
	echo "Error: " . $e->getMessage() . "<br>Line" . $e->getLine();
} finally {
	mysqli_close($con);
}

//$_SESSION["customer_id"] = $customer_ID;
?>

<main>
	<h1>Register Product</h1>
	<table>
	<col style="width:25%">
		<tr><td>
		<form action="register.php" method="post">
			Product: <?php echo "'$line'"?> was registered successfully.
			</td></tr>


	
		</form>

	</table>

	<style>
		table, tr, td {
			border: none;
		}
		td.address {
			width: 500px;
		}
	</style>

	<br>

</main>

<?php include('../view/footer.php');?>

