<!--Produced by: Gabriela Hernandez - registering product into database -->

<?php require('../view/header.php');?>



<?php include('../view/footer.php');?>
