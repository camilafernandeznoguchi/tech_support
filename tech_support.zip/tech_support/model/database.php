<?php
    $username = 'hernandgabr';
    $psw = '8681';

	// Connect to MySQL, select database
	$con = mysqli_connect('webdev.bentley.edu', $username, $psw, $username);
?>