<?php include 'view/header.php'; ?>
<main>
    <h2>Sorry, this page is currently under construction.</h2>
    <p>We'll finish it as quickly as we can. Thanks!</p>
</main>
<?php include 'view/footer.php'; ?>